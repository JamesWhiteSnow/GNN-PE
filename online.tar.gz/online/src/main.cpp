#include "./rtree/rtree.h"
#include "./rtree/rtnode.h"
#include "./rtree/entry.h"
#include "./blockfile/blk_file.h"
#include "./blockfile/cache.h"
#include "./linlist/linlist.h"
#include "./rtree/rtree_cmd.h"
#include "rand.h"
#include "cdf.h"

#include "./graph/graph.h"
#include "custom.h"

#define NOMINMAX
#undef min
#undef max

#include <cmath>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <fstream>
#include <string>
#include <map>
#include <omp.h>
#include <chrono>
#include <cstdio>

using namespace std;
using namespace chrono;

string dataset_path="Datasets/yeast/";

int embedding_dimension = 2;
int partition_number = 5;
int GNN_number = 3;
int path_length = 2;
int path_nodes = path_length + 1;
int query_number = 100;

int main() {
	string filename = dataset_path + "data_graph.txt";
	Graph* data_graph = new Graph(true);
	data_graph->loadGraphFromFile(filename);
	data_graph->printGraphMetaData();

	Partition** partitions = new Partition * [partition_number];
#pragma omp parallel for
	for (int i = 0; i < partition_number; i++) {
		filename = dataset_path + "Partition-" + to_string(i) + "/";
		partitions[i] = new Partition(filename, GNN_number, query_number, data_graph);

		cout << endl << "Partition " << to_string(i) << ":" << endl;

		partitions[i]->build_index();
	}
		
	filename = dataset_path + "query_graphs/";
	Query_Graph** query_graphs = new Query_Graph * [query_number];

#pragma omp parallel for
	for (int i = 0; i < query_number; i++) {
		query_graphs[i] = new Query_Graph(filename, i);
		query_graphs[i]->generate_query_plan_2();
	}

	double query_time = 0;
	for (int query_ID = 0; query_ID < query_number; query_ID++) {
		double search_time = 0;

		vector<vector<Candidate_Path>> global_candidates(query_graphs[query_ID]->query_plan.size());
		vector<vector<int>> global_boundary(query_graphs[query_ID]->query_plan.size());
#pragma omp parallel for reduction(+:search_time)
		for (int i = 0; i < partition_number; i++) {
			vector<vector<int>> candidates;
			search_time += partitions[i]->query(query_graphs[query_ID], query_ID, candidates);

			for (int j = 0; j < global_candidates.size(); j++) {
				for (int k = 0; k < candidates[j].size(); k++) {
					int path_ID = candidates[j][k];
					vector<int> tmp_path(partitions[i]->paths[path_ID], partitions[i]->paths[path_ID] + path_nodes);
					global_boundary[j].push_back(partitions[i]->path_boundary[path_ID]);

					for (int l = 0; l < tmp_path.size(); l++) {
						tmp_path[l] = partitions[i]->graph_extend_map[tmp_path[l]];
					}

					global_candidates[j].push_back(Candidate_Path(tmp_path));
				}
			}
		}

		double time1 = search_time / (1.0 * partition_number);

		double time2 = 0;
#pragma omp parallel for reduction(+:time2)
		for (int i = 0; i < global_candidates.size(); i++) {
			
			vector<Query_Path> query_plan;
			query_plan.push_back(query_graphs[query_ID]->query_plan[i]);
			for (int j = 0; j < query_graphs[query_ID]->query_plan.size(); j++) {
				if (j != i) {
					query_plan.push_back(query_graphs[query_ID]->query_plan[j]);
				}
			}

			vector<unordered_map<int, int>> key_cols(query_plan.size());
			for (int cur_path = 1; cur_path < query_plan.size(); cur_path++) {
				for (int cur_node = 0; cur_node < path_nodes; cur_node++) {
					for (int j = 0; j < cur_path; j++) {
						for (int k = 0; k < path_nodes; k++) {
							if (query_plan[cur_path].nodes[cur_node] == query_plan[j].nodes[k]) {
								auto it = key_cols[cur_path].find(cur_node);
								if (it == key_cols[cur_path].end()) {
									key_cols[cur_path].insert({ cur_node,j * path_nodes + k });
								}
							}
						}
					}
				}
			}

			vector<vector<Candidate_Path>> global_candidates_resort;
			global_candidates_resort.push_back(global_candidates[i]);
			for (int j = 0; j < query_graphs[query_ID]->query_plan.size(); j++) {
				if (j != i) {
					global_candidates_resort.push_back(global_candidates[j]);
				}
			}

			vector<vector<vector<int>>> tables(global_candidates.size());
			for (int j = 0; j < global_candidates.size(); j++) {
				if (j == i) {
					for (int k = 0; k < global_candidates[j].size(); k++) {
						if (global_boundary[j][k] == 1) {
							tables[j].push_back(global_candidates[j][k].nodes);
						}
					}
				}
				else {
					for (int k = 0; k < global_candidates[j].size(); k++) {
						tables[j].push_back(global_candidates[j][k].nodes);
					}
				}
			}
			vector<vector<int>> result;

			typedef chrono::high_resolution_clock Clock;
			auto start_time = Clock::now();
			hash_join(tables, key_cols, result);
			auto end_time = Clock::now();
			time2 += chrono::duration_cast<chrono::nanoseconds>(end_time - start_time).count() / 1e+6;
		}

		query_time += time1 + time2 / global_candidates.size();

		cout << time1 + time2 / global_candidates.size() << endl;
	}

	cout << endl << "Query Number: " << query_number << endl;
	printf("Average Query Time(ms): %.4f\n", query_time / (1.0 * query_number));

	return 0;
}