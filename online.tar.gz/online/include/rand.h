#pragma once

double gaussian(double mean, double sigma);
double uniform(double _min, double _max);
double zipf(double x1, double x2, double p);
