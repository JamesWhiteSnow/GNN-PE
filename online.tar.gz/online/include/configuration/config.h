#pragma once

#define MAXIMUM_QUERY_GRAPH_SIZE 64

#define OPTIMIZED_LABELED_GRAPH 1

#define HYBRID 0


#define SI 0

#define PRINT_SEPARATOR "------------------------------"

